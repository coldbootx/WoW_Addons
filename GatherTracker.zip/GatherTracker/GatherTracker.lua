-- Create the main frame with BackdropTemplate for WoW Classic
GatherTrackerFrame = CreateFrame("Frame", "GatherTrackerFrame", UIParent, "BackdropTemplate")

-- Color codes
local COLOR_GREEN = "|cFF00FF00"
local COLOR_RED = "|cFFFF0000"
local COLOR_YELLOW = "|cFFFFFF00"
local COLOR_CYAN = "|cFF00FFFF"
local COLOR_WHITE = "|cFFFFFFFF"
local COLOR_GREY = "|cFF808080"
local COLOR_BLACK = "|cFF000000"
local COLOR_GOLD = "|cFFFFD700"
local COLOR_BLUE = "|cFF0070DD"
local COLOR_PURPLE = "|cFFA335EE"
local COLOR_PINK = "|cFFFF69B4"
local COLOR_RESET = "|r"

local itemsToTrack = {
    -- Ores
    [11370] = "Dark Iron Ore",
    [10620] = "Thorium Ore",
    -- Herbs and Plants
    [8846] = "Gromsblood",
    [13463] = "Dreamfoil",
    [13465] = "Mt Silversage",
    [13466] = "Plaguebloom",
    [13468] = "Black Lotus",
    -- Crystals
    [12363] = "Arcane Crystal",
    [11382] = "Blood Mountain",
}

local itemCounts = {}

-- Function to get color for item names based on your specifications
local function GetColorForItem(name)
    if name == "Dark Iron Ore" then
        return COLOR_GREY
    elseif name == "Thorium Ore" then
        return COLOR_YELLOW
    elseif name == "Gromsblood" then
        return COLOR_WHITE
    elseif name == "Dreamfoil" then
        return COLOR_PURPLE
    elseif name == "Mt Silversage" then
        return COLOR_GREEN
    elseif name == "Plaguebloom" then
        return COLOR_PINK
    elseif name == "Black Lotus" then
        return COLOR_WHITE
    elseif name == "Arcane Crystal" then
        return COLOR_GOLD
    elseif name == "Blood Mountain" then
        return COLOR_RED
    else
        return COLOR_WHITE
    end
end

-- Define DisplayCounts function to include colorized item names
local function DisplayCounts()
    local text = ""
    for name, count in pairs(itemCounts) do
        local colorCode = GetColorForItem(name)
        text = text .. colorCode .. name .. COLOR_RESET .. ": " .. COLOR_WHITE .. count .. COLOR_RESET .. "\n"
    end
    GatherTrackerFrameText:SetText(text)
end

local function UpdateCounts()
    for itemID, itemName in pairs(itemsToTrack) do
        local count = GetItemCount(itemID)
        itemCounts[itemName] = count
    end
    DisplayCounts()
end

-- Setup the frame appearance
local f = GatherTrackerFrame
f:SetSize(150, 180)
f:SetPoint("CENTER")
f:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background"})
f:SetBackdropColor(0, 0, 0, 0.8)
f:SetMovable(true)
f:EnableMouse(true)
f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", f.StartMoving)
f:SetScript("OnDragStop", f.StopMovingOrSizing)

-- Add a title
local title = f:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -10)
title:SetText("Lil Jalla's Counter")

-- Add the text display
local text = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
text:SetPoint("TOPLEFT", 10, -40)
text:SetSize(120, 120)
text:SetJustifyH("LEFT")
GatherTrackerFrameText = text

f:Show()

-- Register for bag updates
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("BAG_UPDATE")
eventFrame:SetScript("OnEvent", function()
    UpdateCounts()
end)

-- Slash command to toggle visibility
SLASH_GATHERTRACKER1 = "/gt"
function SlashCmdList.GATHERTRACKER()
    if GatherTrackerFrame:IsShown() then
        GatherTrackerFrame:Hide()
    else
        GatherTrackerFrame:Show()
    end
end

-- Run initial update
UpdateCounts()